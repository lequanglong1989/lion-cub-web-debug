@echo off
setlocal
set ROOT=%~dp0..\..
set BUILD_DIR=%ROOT%\tools\web_debug\build
if not exist "%BUILD_DIR%" mkdir "%BUILD_DIR%"
where godot.exe >nul 2>nul
if errorlevel 1 (
  if exist "%ROOT%\Godot_v4.7.2-stable_win64.exe" (
    set GODOT=%ROOT%\Godot_v4.7.2-stable_win64.exe
  ) else (
    echo Godot 4.7.2 not found. Add Godot to PATH or put the executable at project root.
    exit /b 1
  )
) else (
  set GODOT=godot.exe
)
"%GODOT%" --path "%ROOT%" --editor --headless --quit-after 1 > "%TEMP%\lioncub_web_import.log" 2>&1
"%GODOT%" --path "%ROOT%" --export-debug "Web Debug" "%BUILD_DIR%\index.html"
cd /d "%BUILD_DIR%"
echo Lion Cub Web Debug: http://127.0.0.1:8067/
python -m http.server 8067 --bind 127.0.0.1
