# Lion Cub Web Debug

Purpose: export the current main project to a local browser build for fast bug-report testing.

Preset: `Web Debug`
Output: `tools/web_debug/build/index.html`
Local URL: `http://127.0.0.1:8067/`

The web preset uses Godot's non-thread Web export so it does not require cross-origin isolation headers for the local debug workflow.

One-time requirement: install the Godot 4.7.2 Web export template. After that, run:

- Windows: `tools/web_debug/serve_local.bat`
- Linux: `tools/web_debug/serve_local.sh`

Do not treat this browser build as the authoritative QA target. The Godot 4.7.2 desktop runtime remains the source-of-truth QA environment.
