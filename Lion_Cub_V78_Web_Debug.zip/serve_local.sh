#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
GODOT="${GODOT_BIN:-godot}"
BUILD_DIR="$ROOT/tools/web_debug/build"
mkdir -p "$BUILD_DIR"
if ! command -v "$GODOT" >/dev/null 2>&1; then
  echo "Godot executable not found. Set GODOT_BIN=/path/to/Godot_v4.7.2-stable_linux.x86_64"
  exit 1
fi
"$GODOT" --path "$ROOT" --editor --headless --quit-after 1 >/tmp/lioncub_web_import.log 2>&1 || true
"$GODOT" --path "$ROOT" --export-debug "Web Debug" "$BUILD_DIR/index.html"
cd "$BUILD_DIR"
echo "Lion Cub Web Debug: http://127.0.0.1:8067/"
python3 -m http.server 8067 --bind 127.0.0.1
